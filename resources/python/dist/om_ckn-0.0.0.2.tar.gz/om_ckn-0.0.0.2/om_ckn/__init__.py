from om_ckn.functions import f2mc
from om_ckn.functions import Random
